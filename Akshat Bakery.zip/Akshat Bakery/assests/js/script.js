// Assuming you have an array to store cart items
let cart = [];

// Function to add item to cart
/*function addToCart(item) {
    cart.push(item);
    console.log(`${item} added to cart.`);
}

// Example usage
addToCart('Cream Cake');
addToCart('Choco Cake');
addToCart('Slice Cake');
addToCart('Fruit Cake');

// To view the current cart items
//console.log("Cart Items:", cart);*/

function addToCart() {
   
}